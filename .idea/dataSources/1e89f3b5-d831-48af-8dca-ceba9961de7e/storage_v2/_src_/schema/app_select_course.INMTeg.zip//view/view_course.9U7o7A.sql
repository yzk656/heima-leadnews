create definer = root@localhost view view_course as
select `t`.`id`           AS `主键`,
       `teacherid`.`name` AS `教师`,
       `t`.`coursename`   AS `课程名`,
       `t`.`score`        AS `学分`,
       `t`.`indate`       AS `上课时间`,
       `t`.`kaike`        AS `是否开课`
from (`app_select_course`.`tb_course` `t` join `app_select_course`.`tb_teacher` `teacherid`)
where ((1 = 1) and (`t`.`teacherid` = `teacherid`.`id`));

