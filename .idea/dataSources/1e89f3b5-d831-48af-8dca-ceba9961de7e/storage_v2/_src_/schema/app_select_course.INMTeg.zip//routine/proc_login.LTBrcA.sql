create
    definer = root@localhost procedure proc_login(IN usernameP varchar(20), IN passwordP varchar(20))
begin
    if exists(select * from tb_admin where usernameP=username) THEN-- 判断用户是否存在
        begin
        if exists(select * from tb_admin where usernameP=username and passwordP=password)THEN-- 判断密码正确
            select 1 as success,'login success' as message;
        else
            select 0 as success,'login fail' as message;
        END IF;
        end;
    else
        begin
            select 0 as success,'user_does_not_exist' as message;
        end;
    END IF;
end;

