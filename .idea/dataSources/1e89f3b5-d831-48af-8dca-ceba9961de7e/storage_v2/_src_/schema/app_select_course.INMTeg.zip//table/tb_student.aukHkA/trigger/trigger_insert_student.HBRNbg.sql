create definer = root@localhost trigger trigger_insert_student
    before insert
    on tb_student
    for each row
BEGIN
    if LENGTH(new.password)<1 then
        set new.password = '123456';
    end if;
END;

