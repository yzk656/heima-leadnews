create
    definer = root@localhost procedure proc_course(IN idP varchar(255), IN teacheridP varchar(255),
                                                   IN coursenameP varchar(255), IN scoreP int, IN indateP varchar(255),
                                                   IN kaikeP varchar(255))
begin
    if exists(select id from tb_Course where idP=id) then -- update
    begin
        update tb_Course set teacherid=teacheridP,coursename=coursenameP,score=scoreP,indate=indateP,kaike=kaikeP where id=idP;
        select 1 as success,'update-successfully' as message;
    end;
    else -- add
    begin
        insert into tb_Course values(Replace(UUID(),'-','') ,teacheridP,coursenameP,scoreP,indateP,kaikeP );
        select 1 as success,'added-successfully' as message;
    end;
    end if;
end;

