create definer = root@localhost trigger trigger_insert_admin
    before insert
    on tb_admin
    for each row
BEGIN
    if LENGTH(new.password)<1 then
        set new.password = '123456';
    end if;
END;

