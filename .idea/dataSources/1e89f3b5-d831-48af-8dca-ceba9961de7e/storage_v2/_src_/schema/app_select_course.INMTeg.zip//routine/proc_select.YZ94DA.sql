create
    definer = root@localhost procedure proc_select(IN idP varchar(255), IN stuP varchar(255), IN courseidP varchar(255),
                                                   IN createtimeP datetime)
begin
    if exists(select id from tb_Select where idP=id) then -- update
    begin
        update tb_Select set stu=stuP,courseid=courseidP,createtime=createtimeP where id=idP;
        select 1 as success,'update-successfully' as message;
    end;
    else -- add
    begin
        insert into tb_Select values(Replace(UUID(),'-','') ,stuP,courseidP,createtimeP );
        select 1 as success,'added-successfully' as message;
    end;
    end if;
end;

