create definer = root@localhost view view_select as
select `t`.`id` AS `主键`, `stu`.`name` AS `学生名`, `courseid`.`coursename` AS `课程`, `t`.`createtime` AS `选课时间`
from ((`app_select_course`.`tb_select` `t` join `app_select_course`.`tb_student` `stu`) join `app_select_course`.`tb_course` `courseid`)
where ((1 = 1) and (`t`.`stu` = `stu`.`id`) and (`t`.`courseid` = `courseid`.`id`));

