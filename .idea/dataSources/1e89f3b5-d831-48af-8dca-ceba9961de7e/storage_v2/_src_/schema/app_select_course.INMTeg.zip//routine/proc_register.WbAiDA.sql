create
    definer = root@localhost procedure proc_register(IN usernameP varchar(20), IN passwordP varchar(20))
begin
    if exists(select * from tb_admin where usernameP=username) then
        select 0 as success,'username_already_exists' as message;
    else
        begin
            insert into tb_admin (id,username,password) values(Replace(UUID(),'-',''),usernameP,passwordP);
            select 1 as success,'registration_success' as message;
        end;
    end if;
end;

